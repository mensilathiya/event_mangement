import { HiOutlineMenu, HiOutlineLogout } from "react-icons/hi";
import { LuScanQrCode } from "react-icons/lu";
import "../assets/CSS/Header.css";
import QRScannerModal from "./QRScanner/QRScannerModal";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { clearAuth } from "../redux/auth/authSlice";
import Swal from "sweetalert2";

export default function Header({ title = "Dashboard" }) {
  const [openScanner, setOpenScanner] = useState(false);

  const profile = useSelector((state) => state.auth.profile);
  const authUser = useSelector((state) => state.auth.user);
  const token = useSelector((state) => state.auth.token);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Current logged-in user
  // Prefer profile API data, otherwise use login data
  const currentUser = profile || authUser;

  const role = currentUser?.role;

  const userPermissions = Array.isArray(currentUser?.permissions)
    ? currentUser.permissions
    : [];

  // Admin can always scan.
  // Checker/User needs QR Pass permission.
  const canScanQr =
    role === "admin" || userPermissions.includes("QR Pass");

  // Open sidebar
  const handleMenuClick = () => {
    window.dispatchEvent(new Event("toggle-sidebar"));
  };

  // Open QR Scanner
  const handleScanQr = () => {
    setOpenScanner(true);
  };

  // Profile image
  const PROFILE_IMAGE_URL =
    currentUser?.profileImage ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(
      currentUser?.name || "User"
    )}&background=17a2b8&color=ffffff&bold=true`;

  // Logout
  const handleLogout = async () => {
    if (!token) return;

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Are you sure you want to logout?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Logout",
      cancelButtonText: "Cancel",
      reverseButtons: true,
    });

    if (!result.isConfirmed) return;

    // Clear local auth state
    dispatch(clearAuth());

    // Navigate without page refresh
    navigate("/", { replace: true });
  };

  return (
    <>
      <header className="header">
        {/* Hamburger */}
        <button
          type="button"
          className="hamburgerButton"
          onClick={handleMenuClick}
          aria-label="Open sidebar"
        >
          <HiOutlineMenu />
        </button>

        {/* Page Title */}
        <span className="pageTitle">{title}</span>

        <div className="headerRight">
          {/* Scan QR */}
          {canScanQr && (
            <button
              type="button"
              className="scanQrButton"
              onClick={handleScanQr}
            >
              <LuScanQrCode />
              <span>Scan QR</span>
            </button>
          )}

          {/* Logout */}
          <button
            type="button"
            className="logoutButton"
            onClick={handleLogout}
            aria-label="Logout"
            title="Logout"
          >
            <HiOutlineLogout />
          </button>

          {/* Profile */}
          <div
            onClick={() => navigate("/profile")}
            className="profileWrap"
          >
            <img
              src={PROFILE_IMAGE_URL}
              alt={currentUser?.name || "User profile"}
              className="profileImage"
            />
          </div>
        </div>
      </header>

      {/* QR Scanner */}
      <QRScannerModal
        isOpen={openScanner}
        onClose={() => setOpenScanner(false)}
      />
    </>
  );
}